# centrolaruche — Light v1

Sito statico minimale per *La Ruche* pubblicato su GitHub Pages.

## Come modificare
- Sostituisci l'immagine `assets/laruche-hero.jpg` con la foto/cartolina desiderata (stesso nome file).
- Modifica i testi direttamente in `index.html`.
- Colori e tipografia sono in `style.css` (variabili CSS in cima).

## Licenze
- Carica solo immagini e contenuti di cui hai i diritti o che sono di pubblico dominio.
